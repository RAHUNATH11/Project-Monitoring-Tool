# from supabase import create_client

# Replace with your values
# url = "https://jfimfufzlpljtujtrbpq.supabase.co"
# key = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpmaW1mdWZ6bHBsanR1anRyYnBxIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3OTQ0NTI4OCwiZXhwIjoyMDk1MDIxMjg4fQ.gotvAAeSfsBm4oh1l7h4asnGHSkfr2WrNlfRkruAcD0"
from flask import Flask, jsonify, request
from flask_cors import CORS
from supabase import create_client

app = Flask(__name__)
CORS(app)

# ==============================
# SUPABASE CONFIG
# ==============================

url = "https://jfimfufzlpljtujtrbpq.supabase.co"
#key = "YOUR_SUPABASE_KEY"
key = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpmaW1mdWZ6bHBsanR1anRyYnBxIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3OTQ0NTI4OCwiZXhwIjoyMDk1MDIxMjg4fQ.gotvAAeSfsBm4oh1l7h4asnGHSkfr2WrNlfRkruAcD0"

supabase = create_client(url, key)

# ==============================
# GET TICKETS + FILTERS + ANALYTICS
# ==============================

@app.route('/api/users', methods=['GET'])
def get_users():

    # ==============================
    # GET FILTER VALUES
    # ==============================

    status_filters = request.args.getlist('status[]')
    priority_filters = request.args.getlist('priority[]')
    assignee_filters = request.args.getlist('assignee[]')

    # ==============================
    # BASE QUERY
    # ==============================

    query = supabase.table("dev_updates").select("*")

    # ==============================
    # APPLY STATUS FILTER
    # ==============================

    if status_filters:
        query = query.in_("Status", status_filters)

    # ==============================
    # APPLY PRIORITY FILTER
    # ==============================

    if priority_filters:
        query = query.in_("Priority", priority_filters)

    # ==============================
    # APPLY ASSIGNEE FILTER
    # ==============================

    if assignee_filters:
        query = query.in_("Assignee", assignee_filters)

    # ==============================
    # EXECUTE QUERY
    # ==============================

    response = query.execute()

    tickets = response.data

    # ==============================
    # ANALYTICS
    # ==============================

    active_statuses = [
        "In Progress",
        "Test",
        "On Hold"
    ]

    active_count = len([
        t for t in tickets
        if t.get("Status") in active_statuses
    ])

    deploy_count = len([
        t for t in tickets
        if t.get("Status") == "Ready to Deploy"
    ])

    done_count = len([
        t for t in tickets
        if t.get("Status") == "Done"
    ])

    critical_count = len([
        t for t in tickets
        if t.get("Priority") in ["High", "Highest"]
    ])

    analytics = {
        "active": active_count,
        "readyToDeploy": deploy_count,
        "done": done_count,
        "critical": critical_count
    }

    # ==============================
    # RESPONSE
    # ==============================

    return jsonify({
        "tickets": tickets,
        "analytics": analytics
    })

# ==============================
# MAIN
# ==============================

if __name__ == '__main__':
    app.run(debug=True)

# from flask import Flask, jsonify, request
# from flask_cors import CORS
# from supabase import create_client
#
# app = Flask(__name__)
# CORS(app)  # Allow React frontend to call API
#
# # Supabase credentials
# url = "https://jfimfufzlpljtujtrbpq.supabase.co"
# key = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpmaW1mdWZ6bHBsanR1anRyYnBxIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3OTQ0NTI4OCwiZXhwIjoyMDk1MDIxMjg4fQ.gotvAAeSfsBm4oh1l7h4asnGHSkfr2WrNlfRkruAcD0"  # replace with your anon key
#
# supabase = create_client(url, key)
#
# # -----------------------------
# # GET all users
# @app.route('/api/users', methods=['GET'])
# def get_users():
#     response = supabase.table("test_db").select("*").execute()
#     return jsonify(response.data)
#
# # -----------------------------
# # POST new user
# @app.route('/api/users', methods=['POST'])
# def add_user():
#     data = request.json
#     response = supabase.table("test_db").insert(data).execute()
#     return jsonify(response.data)
#
# # -----------------------------
# # DELETE user by id
# @app.route('/api/users/<int:id>', methods=['DELETE'])
# def delete_user(id):
#     response = supabase.table("test_db").delete().eq("id", id).execute()
#     return jsonify(response.data)
#
# # -----------------------------
# if __name__ == '__main__':
#     app.run(debug=True)